//
//  RCDFriendInvitationTableViewCell.h
//  RCloudMessage
//
//  Created by litao on 15/7/30.
//  Copyright (c) 2015年 RongCloud. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <RongIMKit/RongIMKit.h>

@interface RCDFriendInvitationTableViewCell : UITableViewCell
@property (nonatomic, strong)RCMessage *model;
@end
