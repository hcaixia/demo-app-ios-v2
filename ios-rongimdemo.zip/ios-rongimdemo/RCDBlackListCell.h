//
//  RCDBlackListCell.h
//  RCloudMessage
//
//  Created by 蔡建海 on 15/7/14.
//  Copyright (c) 2015年 RongCloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@class RCUserInfo;

@interface RCDBlackListCell : UITableViewCell

//
- (void)setUserInfo:(RCUserInfo *)info;

@end
