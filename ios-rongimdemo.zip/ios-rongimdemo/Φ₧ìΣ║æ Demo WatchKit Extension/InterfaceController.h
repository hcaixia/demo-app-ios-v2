//
//  InterfaceController.h
//  融云 Demo WatchKit Extension
//
//  Created by litao on 15/6/2.
//  Copyright (c) 2015年 RongCloud. All rights reserved.
//

#import <WatchKit/WatchKit.h>
#import <Foundation/Foundation.h>

@interface InterfaceController : WKInterfaceController

@end
