
//
//  ConversationController.h
//  RongIMDemo
//
//  Created by litao on 17/3/26.
//  Copyright (c) 2017年 RongCloud. All rights reserved.
//

#import <WatchKit/WatchKit.h>

@interface ConversationController : WKInterfaceController
- (void)replyVoice;
- (void)replyText;
@end
