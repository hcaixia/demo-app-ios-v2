#!/bin/sh

#  build-imkit.sh
#  RongIMKit
#
#  Created by xugang on 4/8/15.
#  Copyright (c) 2015 RongCloud. All rights reserved.

configuration="Release"
DEV_FLAG=""
VER_FLAG=""
BIN_DIR="bin"
CUR_PATH=$(pwd)

for i in "$@"
do
PFLAG=`echo $i|cut -b1-2`
PPARAM=`echo $i|cut -b3-`
if [ $PFLAG == "-b" ]
then
DEV_FLAG=$PPARAM
elif [ $PFLAG == "-v" ]
then
VER_FLAG=$PPARAM
elif [ $PFLAG == "-t" ]
then
CUR_TIME=$PPARAM
fi
done

if [ ${DEV_FLAG} == "debug" ]
then
configuration="AutoDebug"
sed -i '' -e '/DEMO_VERSION_BOARD/s/@""/@"http:\/\/bj.rongcloud.net\/list.php"/g' ./RCloudMessage/RCDMeTableViewController.m
sed -i '' -e '/redirectNSlogToDocumentFolder/s/\/\///g' ./RCloudMessage/AppDelegate.m

sed  -i "" -e '/UIFileSharingEnabled/{n;s/false/true/; }' ./RCloudMessage/Info.plist 
else
configuration="AutoRelease"
fi

echo $VER_FLAG
echo haha

sed -i ""  -e '/CFBundleShortVersionString/{n;s/[0-9]\.[0-9].[0-9]/'"$VER_FLAG"'/; }' ./RCloudMessage/Info.plist
sed -i ""  -e '/CFBundleVersion/{n;s/[0-9]*[0-9]/'"$CUR_TIME"'/; }' ./RCloudMessage/Info.plist

sed  -i "" -e '/CFBundleShortVersionString/{n;s/[0-9]\.[0-9].[0-9]/'"$VER_FLAG"'/; }' ./融云\ Demo\ WatchKit\ App/Info.plist
sed -i ""  -e '/CFBundleVersion/{n;s/[0-9]*[0-9]/'"$CUR_TIME"'/; }' ./融云\ Demo\ WatchKit\ App/Info.plist

sed -i "" -e '/CFBundleShortVersionString/{n;s/[0-9]\.[0-9].[0-9]/'"$VER_FLAG"'/; }' ./融云\ Demo\ WatchKit\ Extension/Info.plist 
sed -i ""  -e '/CFBundleVersion/{n;s/[0-9]*[0-9]/'"$CUR_TIME"'/; }' ./融云\ Demo\ WatchKit\ Extension/Info.plist

PROJECT_NAME="RCloudMessage.xcodeproj"
targetName="RCloudMessage"
TARGET_DECIVE="iphoneos"
#TARGET_I386="iphonesimulator"

if [ ! -d "$BIN_DIR" ]; then
mkdir -p "$BIN_DIR"
fi

xcodebuild clean -configuration $configuration -sdk $TARGET_DECIVE
#xcodebuild clean -configuration $configuration -sdk $TARGET_I386

echo "***开始build iphoneos文件***"
xcodebuild -project ${PROJECT_NAME} -target $targetName -configuration $configuration APP_PROFILE="5935ba81-982a-494c-afb1-a673b8d21d32" WATCHKIT_EXTENSION_PROFILE="c321013f-58a3-4688-a239-1bb9b6fb375e" WATCHKIT_APP_PROFILE="b207ece9-7356-4c38-b6ee-ca121311b56f" CODE_SIGN_IDENTITY="iPhone Distribution: Beijing Rong Cloud Network Technology CO., LTD"
xcrun -sdk $TARGET_DECIVE PackageApplication -v ./build/${configuration}-${TARGET_DECIVE}/*.app -o ${CUR_PATH}/${BIN_DIR}/RCloudMessage_v${VER_FLAG}_${CUR_TIME}_${DEV_FLAG}.ipa

echo "***编译结束***"