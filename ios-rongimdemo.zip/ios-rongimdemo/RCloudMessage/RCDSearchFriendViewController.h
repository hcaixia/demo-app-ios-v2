//
//  RCDSearchFriendTableViewController.h
//  RCloudMessage
//
//  Created by Liv on 15/3/12.
//  Copyright (c) 2015年 RongCloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RCDSearchFriendViewController : UITableViewController

/**
 *  factory method
 *
 *  @return return a instance
 */
+(instancetype) searchFriendViewController;



@end
