//
//  RCDMeTableViewController.h
//  RCloudMessage
//
//  Created by Liv on 14/11/28.
//  Copyright (c) 2014年 RongCloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RCDMeTableViewController : UITableViewController
@property (weak, nonatomic) IBOutlet UILabel *versionLb;

@end
