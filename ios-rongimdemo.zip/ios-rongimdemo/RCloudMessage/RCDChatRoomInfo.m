//
//  RCDChatRoomInfo.m
//  RCloudMessage
//
//  Created by 杜立召 on 15/3/26.
//  Copyright (c) 2015年 RongCloud. All rights reserved.
//

#import "RCDChatRoomInfo.h"

@implementation RCDChatRoomInfo

@end
