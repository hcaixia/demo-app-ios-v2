//
//  RCDUserInfo.m
//  RCloudMessage
//
//  Created by 杜立召 on 15/3/21.
//  Copyright (c) 2015年 RongCloud. All rights reserved.
//

#import "RCDUserInfo.h"

@implementation RCDUserInfo

@synthesize name;
@end
