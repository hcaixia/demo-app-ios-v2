//
//  RCDAddressBookTableViewCell.m
//  RCloudMessage
//
//  Created by Liv on 15/3/13.
//  Copyright (c) 2015年 RongCloud. All rights reserved.
//

#import "RCDAddressBookTableViewCell.h"
//#import <QuartzCore/QuartzCore.h>

@implementation RCDAddressBookTableViewCell

- (void)awakeFromNib {
    // Initialization code
//    _imgvAva.layer.masksToBounds = YES;
//    _imgvAva.layer.cornerRadius = 8.f;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
