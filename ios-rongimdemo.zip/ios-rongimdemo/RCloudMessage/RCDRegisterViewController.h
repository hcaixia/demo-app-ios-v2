//
//  RCDRegisterViewController.h
//  RCloudMessage
//
//  Created by Liv on 15/3/10.
//  Copyright (c) 2015年 RongCloud. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RCAnimatedImagesView.h"
@interface RCDRegisterViewController : UIViewController<RCAnimatedImagesViewDelegate>

@end
