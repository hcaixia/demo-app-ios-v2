//
//  RCConversationSettingTableViewCell.h
//  RongIMToolkit
//
//  Created by Liv on 15/3/25.
//  Copyright (c) 2015年 RongCloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RCDDiscussSettingSwitchCell : UITableViewCell

@property (nonatomic,strong) UISwitch *swich;
@property (nonatomic,strong) UILabel *label;

@end