//
//  RCDConversationSettingTableViewCell.h
//  RCloudMessage
//
//  Created by 杜立召 on 15/7/21.
//  Copyright (c) 2015年 RongCloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RCDConversationSettingTableViewCell : UITableViewCell

@property(nonatomic, strong) UISwitch *swich;
@property(nonatomic, strong) UILabel *label;

@end
