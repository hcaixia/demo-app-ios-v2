//
//  RCDRoomSettingViewController.h
//  RCloudMessage
//
//  Created by Liv on 15/4/8.
//  Copyright (c) 2015年 RongCloud. All rights reserved.
//

#import <RongIMKit/RongIMKit.h>
#import "RCDSettingBaseViewController.h"

@interface RCDRoomSettingViewController : RCDSettingBaseViewController

@end
