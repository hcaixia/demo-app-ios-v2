//
//  RCDSettingsTableViewController.h
//  RCloudMessage
//
//  Created by Liv on 14/11/20.
//  Copyright (c) 2014年 RongCloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RCDSettingsTableViewController : UITableViewController

@end
