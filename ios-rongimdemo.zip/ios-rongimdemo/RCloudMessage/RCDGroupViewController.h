//
//  SecondViewController.h
//  RongCloud
//
//  Created by Liv on 14/10/31.
//  Copyright (c) 2014年 RongCloud. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "RCGroupListViewController.h"

@interface RCDGroupViewController : UITableViewController


@end

