//
//  RCDDiscussSettingCell.h
//  RCloudMessage
//
//  Created by Liv on 15/4/2.
//  Copyright (c) 2015年 RongCloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RCDDiscussSettingCell : UITableViewCell

@property (strong, nonatomic) UILabel *lblDiscussName;
@property (strong, nonatomic) UILabel *lblTitle;

@end
