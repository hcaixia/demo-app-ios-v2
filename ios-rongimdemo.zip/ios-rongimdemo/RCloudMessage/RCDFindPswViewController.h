//
//  RCDFindPswViewController.h
//  RCloudMessage
//
//  Created by 杜立召 on 15/3/23.
//  Copyright (c) 2015年 RongCloud. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RCAnimatedImagesView.h"
@interface RCDFindPswViewController : UIViewController<RCAnimatedImagesViewDelegate>

@end
