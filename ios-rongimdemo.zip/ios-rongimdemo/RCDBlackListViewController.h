//
//  RCDBlackListViewController.h
//  RCloudMessage
//
//  Created by 蔡建海 on 15/7/13.
//  Copyright (c) 2015年 RongCloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RCDBlackListViewController : UITableViewController

@end
