//
//  RCDPrivateViewController.h
//  RCloudMessage
//
//  Created by Liv on 15/4/21.
//  Copyright (c) 2015年 RongCloud. All rights reserved.
//

#import "RCDDiscussGroupSettingViewController.h"

@interface RCDPrivateSettingViewController : RCDDiscussGroupSettingViewController

@end
